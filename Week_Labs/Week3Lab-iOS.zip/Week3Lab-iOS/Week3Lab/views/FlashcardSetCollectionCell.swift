//
//  FlashcardSetCollectionCell.swift
//  Week3Lab
//
//  Created by Andrew Taylor on 1/22/23.
//

import UIKit

class FlashcardSetCollectionCell: UICollectionViewCell {
    @IBOutlet weak var titleLabel: UILabel!
}

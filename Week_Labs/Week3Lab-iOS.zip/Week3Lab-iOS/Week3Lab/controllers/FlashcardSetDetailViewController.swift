//
//  FlashcardSetDetailViewController.swift
//  Week3Lab
//
//  Created by Andrew Taylor on 1/22/23.
//

import UIKit

class FlashcardSetDetailViewController: UIViewController, UITableViewDelegate, UITableViewDataSource  {
    @IBOutlet weak var tableView: UITableView!
    var flashcardSet: FlashcardSet!
    var flashcards = getFlashcards()

    @IBAction func addFlashcardTapped(_ sender: UIButton) {
        let newFlashcard = Flashcard(term: "New Term", definition: "New Definition")
        flashcards.append(newFlashcard)
        tableView.reloadData()
    }
    @IBAction func deleteSetTapped(_ sender: UIButton) {
        print("Delete button tapped")
        // Optional: Add logic later to remove set
    }

    @IBAction func studySetTapped(_ sender: UIButton) {
        print("Study button tapped")
        // Optional: Navigate to study mode in future
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // use the below to set the dataSource and delegate
        
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return number of items
        return flashcards.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FlashcardCell", for: indexPath) as! FlashcardTableCell
        
        //setup cell display here -- use indexPath.row to get position
        let flashcard = flashcards[indexPath.row]
        cell.flashcardLabel.text = flashcard.term
        
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
            if editingStyle == .delete {
                flashcards.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .automatic)
            }
        }
}

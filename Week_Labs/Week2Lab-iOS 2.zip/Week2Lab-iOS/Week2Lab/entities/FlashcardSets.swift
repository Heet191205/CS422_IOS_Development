//
//  FlashcardSets.swift
//  Week2Lab
//
//  Created by Heet Shah on 6/14/25.
//
import Foundation
class FlashcardSets {
    var title: String
    init(title: String) {
        self.title = title
    }
}

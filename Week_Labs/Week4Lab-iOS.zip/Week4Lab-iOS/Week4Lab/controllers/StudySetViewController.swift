//
//  StudySetViewController.swift
//  Week4Lab
//
//  Created by Andrew Taylor on 1/29/23.
//

import UIKit

class StudySetViewController: UIViewController {
    
    @IBOutlet weak var flashcardLabel: UILabel!
    @IBOutlet weak var progressLabel: UILabel!
    @IBOutlet weak var missedLabel: UILabel!
    @IBOutlet weak var correctLabel: UILabel!
    
    var flashcards = getFlashcards()
    var currentIndex = 0
    var showDef = false
    
    var missedSet = Set<Int>()
    var correctCount = 0
    var missedCount = 0
    var skippedSet = Set<Int>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateDisplay()
        
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(SwipeGesture(_:)))
            swipeUp.direction = .up
            flashcardLabel.addGestureRecognizer(swipeUp)

            // Swipe Left to Miss
            let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(SwipeGesture(_:)))
            swipeLeft.direction = .left
            flashcardLabel.addGestureRecognizer(swipeLeft)

            // Swipe Right to Correct
            let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(SwipeGesture(_:)))
            swipeRight.direction = .right
            flashcardLabel.addGestureRecognizer(swipeRight)

            flashcardLabel.isUserInteractionEnabled = true
    }
    
    @objc func SwipeGesture(_ gesture: UISwipeGestureRecognizer) {
        switch gesture.direction {
        case .up:
            skipTapped(UIButton())  // simulate skip
        case .left:
            missedTapped(UIButton())  // simulate missed
        case .right:
            correctTapped(UIButton())  // simulate correct
        default:
            break
        }
    }
    
    @IBAction func TapGesutre(_ sender: UITapGestureRecognizer) {
        guard currentIndex < flashcards.count else {
            return
        }
        let card = flashcards[currentIndex]
        flashcardLabel.text = showDef ? card.term : card.definition
        showDef.toggle()
        
    }
    
    func updateDisplay() {
        guard !flashcards.isEmpty else {
            flashcardLabel.text = "Term Completed!"
            showDef = false
            updateStats()
            return
        }
        if currentIndex >= flashcards.count {
            if let next = skippedSet.first {
                currentIndex = next
                skippedSet.remove(next)
            } else {
                flashcardLabel.text = "Term Completed!"
                showDef = false
                updateStats()
            return
            }
        }
        let card = flashcards[currentIndex]
            flashcardLabel.text = card.term
            showDef = false
            updateStats()
    }
    
    func updateStats() {
        missedLabel.text = "Missed: \(missedCount)"
        correctLabel.text = "Correct: \(correctCount)"
        let remaining = flashcards.count + skippedSet.count
        let completed = correctCount + missedCount
                progressLabel.text = "\(completed)/\(remaining) completed"
    }
    
    @IBAction func skipTapped(_ sender: UIButton) {
        if currentIndex < flashcards.count {
            skippedSet.insert(currentIndex)
            currentIndex += 1
            updateDisplay()
        }
    }
        
    @IBAction func missedTapped(_ sender: UIButton) {
        guard currentIndex < flashcards.count else {
            return
        }
        if !missedSet.contains(currentIndex) {
            missedSet.insert(currentIndex)
            missedCount += 1
        }
            currentIndex += 1
            updateDisplay()
    }
        
    @IBAction func correctTapped(_ sender: UIButton) {
        guard currentIndex < flashcards.count else {
            updateDisplay()
            return
        }
        if !missedSet.contains(currentIndex) {
            correctCount += 1
        }
        flashcards.remove(at: currentIndex)
        
        if currentIndex >= flashcards.count {
            currentIndex = 0
        }
        updateDisplay()
    }
        
    func quitStudying() {
        self.dismiss(animated: true)
    }
}

//
//  FlashcardSetDetailViewController.swift
//
//  Created by Andrew Taylor on 1/22/23.
//

import UIKit

class FlashcardSetDetailViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    var flashcards = getFlashcards()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return flashcards.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FlashcardCell", for: indexPath) as! FlashcardTableCell
        cell.flashcardLabel.text = flashcards[indexPath.row].term
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        createAlert(indexPath: indexPath)
    }

    func createAlert(indexPath: IndexPath) {
        let flashcard = flashcards[indexPath.row]
        let alert = UIAlertController(title: flashcard.term, message: flashcard.definition, preferredStyle: .alert)

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Edit", style: .default, handler: { _ in
            alert.dismiss(animated: true)
            self.createEditableAlert(indexPath: indexPath)
        }))

        present(alert, animated: true)
    }

    func createEditableAlert(indexPath: IndexPath) {
        let flashcard = flashcards[indexPath.row]
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .alert)

        alert.addTextField { $0.text = flashcard.term }
        alert.addTextField { $0.text = flashcard.definition }

        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { _ in
            self.flashcards.remove(at: indexPath.row)
            self.tableView.deleteRows(at: [indexPath], with: .automatic)
        }))

        alert.addAction(UIAlertAction(title: "Done", style: .default, handler: { _ in
            guard let Term = alert.textFields?[0].text,
                  let Def = alert.textFields?[1].text else { return }

            self.flashcards[indexPath.row] = Flashcard(term: Term, definition: Def)
            self.tableView.reloadRows(at: [indexPath], with: .automatic)
        }))

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    // swipe to delete
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            flashcards.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }

    @IBAction func addFlashcard(_ sender: Any) {
        flashcards.append(Flashcard(term: "New Term", definition: "New Definition"))
        tableView.reloadData()
        tableView.scrollToRow(at: IndexPath(item: flashcards.count - 1, section: 0), at: .bottom, animated: true)
    }
}

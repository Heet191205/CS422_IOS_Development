//
//  ViewController.swift
//
//  Created by Andrew Taylor on 1/22/23.
//

import UIKit
import CoreData

class MainViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource  {
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    @IBOutlet weak var collectionView: UICollectionView!
    var sets: [FlashcardSet] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        fetchFlashcardSets()
    }
    
    func fetchFlashcardSets() {
        let request: NSFetchRequest<FlashcardSet> = FlashcardSet.fetchRequest()
        do {
            sets = try context.fetch(request)
            collectionView.reloadData()
        } catch {
            print("Failed to fetch FlashcardSets: \(error)")
        }
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return sets.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FlashcardSetCell", for: indexPath) as! FlashcardSetCollectionCell
        cell.myLabel.text = sets[indexPath.row].title
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        performSegue(withIdentifier: "GoToDetail", sender: self)
    }
    
    @IBAction func addFlashcardSet(_ sender: Any) {
        let newSet = FlashcardSet(context: context)
        newSet.title = "New Set"
        
        do {
            try context.save()
            fetchFlashcardSets()
            collectionView.scrollToItem(at: IndexPath(item: sets.count - 1, section: 0), at: .bottom, animated: true)
        } catch {
            print("Could not save new set: \(error)")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "GoToDetail",
           let destination = segue.destination as? FlashcardSetDetailViewController,
           let indexPath = collectionView.indexPathsForSelectedItems?.first {
            destination.flashcardSet = sets[indexPath.row]
        }
    }
}

//
//  FlashcardSetDetailViewController.swift
//
//  Created by Andrew Taylor on 1/22/23.
//

import UIKit
import Alamofire
import CoreData

class FlashcardSetDetailViewController: UIViewController, UITableViewDelegate, UITableViewDataSource  {

    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet weak var tableView: UITableView!
        
    var flashcards: [Flashcard] = []
    var flashcardSet: FlashcardSet!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if flashcardSet != nil {
            fetchFlashcards()
        }
    }

    func fetchFlashcards() {
        let request: NSFetchRequest<Flashcard> = Flashcard.fetchRequest()
        request.predicate = NSPredicate(format: "set == %@", flashcardSet)
        do {
            flashcards = try context.fetch(request)
            tableView.reloadData()
        } catch {
            print("Failed to fetch flashcards: \(error)")
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return flashcards.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FlashcardCell", for: indexPath) as! FlashcardTableCell
        cell.flashcardLabel.text = flashcards[indexPath.row].term
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let flashcard = flashcards[indexPath.row]
        let alert = UIAlertController(title: flashcard.term, message: flashcard.definition, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Edit", style: .default, handler: { _ in
            self.showEditAlert(indexPath: indexPath)
        }))
        alert.addAction(UIAlertAction(title: "Done", style: .cancel))
        
        present(alert, animated: true)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            flashcards.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    @IBAction func addFlashcard(_ sender: Any) {
        guard let flashcardSet = flashcardSet else { return }

        let newCard = Flashcard(context: context)
        newCard.term = "New Term"
        newCard.definition = "New Definition"
        newCard.set = flashcardSet

        do {
            try context.save()
            fetchFlashcards()
            if !flashcards.isEmpty {
                tableView.scrollToRow(at: IndexPath(row: flashcards.count - 1, section: 0), at: .bottom, animated: true)
            }
        } catch {
            print("Error saving new flashcard: \(error)")
        }
    }
    
    func showEditAlert(indexPath: IndexPath) {
        let flashcard = flashcards[indexPath.row]
        let alert = UIAlertController(title: "Edit Flashcard", message: nil, preferredStyle: .alert)
            
        alert.addTextField { $0.text = flashcard.term }
        alert.addTextField { $0.text = flashcard.definition }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { _ in
            self.context.delete(flashcard)
            do {
                try self.context.save()
                self.fetchFlashcards()
            } catch {
                print("Error deleting flashcard: \(error)")
            }
        }))
            
        alert.addAction(UIAlertAction(title: "Done", style: .default, handler: { _ in
            flashcard.term = alert.textFields?[0].text ?? ""
            flashcard.definition = alert.textFields?[1].text ?? ""
            do {
                try self.context.save()
                self.fetchFlashcards()
            } catch {
                print("Error updating flashcard: \(error)")
            }
        }))
        
        present(alert, animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "GoToStudy",
           let destination = segue.destination as? StudySetViewController {
            destination.flashcardSet = self.flashcardSet
        }
    }
}

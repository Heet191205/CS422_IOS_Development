//
//  StudySetViewController.swift
//  Week5Lab
//
//  Created by Andrew Taylor on 1/29/23.
//

import UIKit
import CoreData

class StudySetViewController: UIViewController  {
    
    @IBOutlet weak var correctCountLabel: UILabel!
    @IBOutlet weak var missedCountLabel: UILabel!
    @IBOutlet weak var completedCountLabel: UILabel!
    @IBOutlet weak var currentLabel: UILabel!
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var flashcards: [Flashcard] = []
    var flashcardSet: FlashcardSet!
    var isShowingDefinition = false
    var totalAmount = 0
    var position = 0
    var missed: [Flashcard] = []
    var correct = 0
    var completed = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        currentLabel.isUserInteractionEnabled = true
        currentLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(currentLabelClicked)))
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if flashcardSet != nil {
            fetchFlashcards()
        }
    }
    
    func fetchFlashcards() {
        let request: NSFetchRequest<Flashcard> = Flashcard.fetchRequest()
        request.predicate = NSPredicate(format: "set == %@", flashcardSet)
        
        do {
            flashcards = try context.fetch(request)
            totalAmount = flashcards.count
            position = 0
            isShowingDefinition = false
            missed = []
            correct = 0
            completed = 0
            
            correctCountLabel.text = "Correct: 0"
            missedCountLabel.text = "Missed: 0"
            completedCountLabel.text = "0 / \(totalAmount)"
            
            updateCurrentCard()
        } catch {
            print("Failed to fetch flashcards for study: \(error)")
        }
    }
    
    @objc func currentLabelClicked() {
        isShowingDefinition.toggle()
        updateCurrentCard()
    }

    func updateCurrentCard() {
        if isComplete() {
            currentLabel.text = "Set Complete!!!"
        } else if isShowingDefinition {
            currentLabel.text = flashcards[position].definition
        } else {
            currentLabel.text = flashcards[position].term
        }
    }
    
    func isComplete() -> Bool {
        return flashcards.isEmpty
    }
    
    @IBAction func skipCurrent(_ sender: Any) {
        guard !isComplete() else { return }
        position = (position + 1) % flashcards.count
        isShowingDefinition = false
        updateCurrentCard()
    }
    
    @IBAction func missCurrent(_ sender: Any) {
        guard !isComplete() else { return }
        
        let current = flashcards[position]
        if !missed.contains(current) {
            missed.append(current)
            missedCountLabel.text = "Missed: \(missed.count)"
        }
        position = (position + 1) % flashcards.count
        isShowingDefinition = false
        updateCurrentCard()
    }
    
    @IBAction func correctCurrent(_ sender: Any) {
        guard !isComplete() else { return }
        
        flashcards.remove(at: position)
        correct += 1
        completed += 1
        correctCountLabel.text = "Correct: \(correct)"
        completedCountLabel.text = "\(completed) / \(totalAmount)"
        
        if flashcards.isEmpty {
            updateCurrentCard()
            return
        }
        
        if position >= flashcards.endIndex { position = 0 }
        isShowingDefinition = false
        updateCurrentCard()
    }
}

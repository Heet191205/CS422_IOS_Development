//
//  Flashcard+CoreDataProperties.swift
//  Week5Lab
//
//  Created by Heet Shah on 7/5/25.
//
//

import Foundation
import CoreData


extension Flashcard {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Flashcard> {
        return NSFetchRequest<Flashcard>(entityName: "Flashcard")
    }

    @NSManaged public var definition: String?
    @NSManaged public var term: String?
    @NSManaged public var set: FlashcardSet?

}

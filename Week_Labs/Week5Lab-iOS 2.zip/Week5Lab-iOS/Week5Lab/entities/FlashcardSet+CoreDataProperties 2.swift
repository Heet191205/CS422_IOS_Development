//
//  FlashcardSet+CoreDataProperties.swift
//  Week5Lab
//
//  Created by Heet Shah on 7/5/25.
//
//

import Foundation
import CoreData


extension FlashcardSet {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<FlashcardSet> {
        return NSFetchRequest<FlashcardSet>(entityName: "FlashcardSet")
    }

    @NSManaged public var title: String?
    @NSManaged public var flashcards: Flashcard?

}

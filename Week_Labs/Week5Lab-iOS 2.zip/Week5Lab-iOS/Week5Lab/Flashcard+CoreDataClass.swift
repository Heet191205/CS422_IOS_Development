//
//  Flashcard+CoreDataClass.swift
//  Week5Lab
//
//  Created by Heet Shah on 7/5/25.
//
//

import Foundation
import CoreData

@objc(Flashcard)
public class Flashcard: NSManagedObject {

}

//
//  FlashcardSet+CoreDataProperties.swift
//  Week5Lab
//
//  Created by Heet Shah on 7/6/25.
//
//

import Foundation
import CoreData


extension FlashcardSet {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<FlashcardSet> {
        return NSFetchRequest<FlashcardSet>(entityName: "FlashcardSet")
    }

    @NSManaged public var title: String?
    @NSManaged public var flashcards: NSSet?

}

// MARK: Generated accessors for flashcards
extension FlashcardSet {

    @objc(addFlashcardsObject:)
    @NSManaged public func addToFlashcards(_ value: Flashcard)

    @objc(removeFlashcardsObject:)
    @NSManaged public func removeFromFlashcards(_ value: Flashcard)

    @objc(addFlashcards:)
    @NSManaged public func addToFlashcards(_ values: NSSet)

    @objc(removeFlashcards:)
    @NSManaged public func removeFromFlashcards(_ values: NSSet)

}

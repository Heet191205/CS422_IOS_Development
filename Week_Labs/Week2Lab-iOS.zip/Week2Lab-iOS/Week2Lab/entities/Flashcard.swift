//
//  Flashcard.swift
//  Week2Lab
//
//  Created by Heet Shah on 6/14/25.
//

import Foundation

class Flashcard {
    var term: String
    var definition: String
    
    init(term: String, definition: String) {
        self.term = term
        self.definition = definition
    }
}

//
//  Provider.swift
//  Week2Lab
//
//  Created by Heet Shah on 6/14/25.
//

import Foundation

func getFlashcards() -> [Flashcard] {
    return [ // Term and Definitions
        Flashcard(term: "T1", definition: "Def 1"), Flashcard(term: "T2", definition: "Def 2"),
        Flashcard(term: "T3", definition: "Def 3"), Flashcard(term: "T4", definition: "Def 4"),
        Flashcard(term: "T5", definition: "Def 5"), Flashcard(term: "T6", definition: "Def 6"),
        Flashcard(term: "T7", definition: "Def 7"), Flashcard(term: "T8", definition: "Def 8"),
        Flashcard(term: "T9", definition: "Def 9"), Flashcard(term: "T10", definition: "Def 10")
    ]
}
func getFlashcardSets() -> [FlashcardSets] {
    return [ // Sets (array of 10 FlashcardSets)
        FlashcardSets(title: "S 1"), FlashcardSets(title: "S 2"),
        FlashcardSets(title: "S 3"), FlashcardSets(title: "S 4"),
        FlashcardSets(title: "S 5"), FlashcardSets(title: "S 6"),
        FlashcardSets(title: "S 7"), FlashcardSets(title: "S 8"),
        FlashcardSets(title: "S 9"), FlashcardSets(title: "S 10")
    ]
}

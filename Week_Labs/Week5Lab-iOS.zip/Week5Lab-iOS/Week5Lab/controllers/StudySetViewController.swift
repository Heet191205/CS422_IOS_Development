import UIKit

class StudySetViewController: UIViewController {
    
    @IBOutlet weak var correctCountLabel: UILabel!
    @IBOutlet weak var missedCountLabel: UILabel!
    @IBOutlet weak var completedCountLabel: UILabel!
    @IBOutlet weak var currentLabel: UILabel!
    
    var flashcardSet: FlashcardSet!
    var engine: CardEngine!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        currentLabel.isUserInteractionEnabled = true
        currentLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(flip)))
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        engine = CardEngine(for: flashcardSet)
        updateStats()
        updateCard()
    }

    @objc func flip() {
        engine.toggle()
        updateCard()
    }

    @IBAction func skip(_ sender: Any) {
        engine.advance()
        updateCard()
    }

    @IBAction func markMissed(_ sender: Any) {
        engine.miss()
        updateStats()
        updateCard()
    }

    @IBAction func markCorrect(_ sender: Any) {
        engine.markCorrect()
        updateStats()
        updateCard()
    }

    func updateCard() {
        currentLabel.text = engine.currentDisplay()
    }

    func updateStats() {
        correctCountLabel.text = "Correct: \(engine.correct)"
        missedCountLabel.text = "Missed: \(engine.missed)"
        completedCountLabel.text = "\(engine.completed) / \(engine.total)"
    }
}

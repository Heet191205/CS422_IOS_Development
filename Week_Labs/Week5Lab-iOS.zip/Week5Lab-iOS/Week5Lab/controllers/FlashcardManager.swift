//
//  FlashcardManager.swift
//  Week5Lab
//
//  Created by Jeet Patel on 7/6/25.
//


import UIKit
import CoreData

struct FlashcardManager {
    static var context: NSManagedObjectContext {
        (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    }

    static func cards(in set: FlashcardSet) -> [Flashcard] {
        let request: NSFetchRequest<Flashcard> = Flashcard.fetchRequest()
        request.predicate = NSPredicate(format: "set == %@", set)
        return (try? context.fetch(request)) ?? []
    }

    static func addCard(to set: FlashcardSet, term: String, def: String) {
        let newCard = Flashcard(context: context)
        newCard.term = term
        newCard.definition = def
        newCard.set = set
        try? context.save()
    }

    static func removeCard(_ card: Flashcard) {
        context.delete(card)
        try? context.save()
    }

    static func saveChanges() {
        try? context.save()
    }
}

//
//  CardEngine.swift
//  Week5Lab
//
//  Created by Jeet Patel on 7/6/25.
//


import UIKit
import CoreData

class CardEngine {
    
    private var cards: [Flashcard] = []
    private var index = 0
    private var isFlipped = false
    
    var missedList: [Flashcard] = []
    var correct = 0
    var completed = 0
    var total = 0
    
    init(for set: FlashcardSet) {
        let ctx = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let r: NSFetchRequest<Flashcard> = Flashcard.fetchRequest()
        r.predicate = NSPredicate(format: "set == %@", set)
        cards = (try? ctx.fetch(r)) ?? []
        total = cards.count
    }

    func toggle() {
        isFlipped.toggle()
    }

    func currentDisplay() -> String {
        if cards.isEmpty { return "Done Studying!" }
        let c = cards[index]
        return isFlipped ? c.definition ?? "" : c.term ?? ""
    }

    func advance() {
        guard !cards.isEmpty else { return }
        index = (index + 1) % cards.count
        isFlipped = false
    }

    func miss() {
        if !cards.isEmpty && !missedList.contains(cards[index]) {
            missedList.append(cards[index])
        }
        advance()
    }

    func markCorrect() {
        guard !cards.isEmpty else { return }
        let current = cards.remove(at: index)
        if index >= cards.count { index = 0 }
        completed += 1
        if !missedList.contains(current) {
            correct += 1
        }
        isFlipped = false
    }

    var missed: Int {
        return missedList.count
    }
}

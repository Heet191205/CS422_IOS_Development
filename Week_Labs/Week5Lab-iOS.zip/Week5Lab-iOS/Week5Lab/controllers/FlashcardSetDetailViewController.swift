import UIKit

class FlashcardSetDetailViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!

    var flashcards = [Flashcard]()
    var flashcardSet: FlashcardSet!

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        flashcards = FlashcardManager.cards(in: flashcardSet)
        tableView.reloadData()
    }

    @IBAction func addFlashcard(_ sender: Any) {
        FlashcardManager.addCard(to: flashcardSet, term: "New Term", def: "New Definition")
        flashcards = FlashcardManager.cards(in: flashcardSet)
        tableView.reloadData()
        if flashcards.count > 0 {
            tableView.scrollToRow(at: IndexPath(row: flashcards.count - 1, section: 0), at: .bottom, animated: true)
        }
    }

    func tableView(_ t: UITableView, numberOfRowsInSection s: Int) -> Int {
        flashcards.count
    }

    func tableView(_ t: UITableView, cellForRowAt i: IndexPath) -> UITableViewCell {
        let cell = t.dequeueReusableCell(withIdentifier: "FlashcardCell", for: i) as! FlashcardTableCell
        cell.flashcardLabel.text = flashcards[i.row].term
        return cell
    }

    func tableView(_ t: UITableView, didSelectRowAt i: IndexPath) {
        let card = flashcards[i.row]
        let alert = UIAlertController(title: card.term, message: card.definition, preferredStyle: .alert)

        alert.addAction(UIAlertAction(title: "Edit", style: .default, handler: { _ in self.presentEditor(for: i.row) }))
        alert.addAction(UIAlertAction(title: "Done", style: .cancel))
        present(alert, animated: true)
    }

    func presentEditor(for index: Int) {
        let f = flashcards[index]
        let editor = UIAlertController(title: nil, message: nil, preferredStyle: .alert)
        editor.addTextField { $0.text = f.term }
        editor.addTextField { $0.text = f.definition }

        editor.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        editor.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { _ in
            FlashcardManager.removeCard(f)
            self.flashcards = FlashcardManager.cards(in: self.flashcardSet)
            self.tableView.reloadData()
        }))
        editor.addAction(UIAlertAction(title: "Done", style: .default, handler: { _ in
            f.term = editor.textFields?[0].text ?? ""
            f.definition = editor.textFields?[1].text ?? ""
            FlashcardManager.saveChanges()
            self.tableView.reloadRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
        }))
        present(editor, animated: true)
    }

    func tableView(_ t: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt i: IndexPath) {
        if editingStyle == .delete {
            FlashcardManager.removeCard(flashcards[i.row])
            flashcards = FlashcardManager.cards(in: flashcardSet)
            tableView.reloadData()
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "GoToStudy",
           let target = segue.destination as? StudySetViewController {
            target.flashcardSet = flashcardSet
        }
    }
}

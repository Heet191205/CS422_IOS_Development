//
//  FlashcardHelper.swift
//  Week5Lab
//
//  Created by Jeet Patel on 7/6/25.
//

import UIKit
import CoreData

struct FlashcardHelper {

    static var context: NSManagedObjectContext {
        return (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    }

    static func loadFlashcardSets() -> [FlashcardSet] {
        let request: NSFetchRequest<FlashcardSet> = FlashcardSet.fetchRequest()
        return (try? context.fetch(request)) ?? []
    }

    static func addNewSet(titled title: String) {
        let newSet = FlashcardSet(context: context)
        newSet.title = title
        try? context.save()
    }
}

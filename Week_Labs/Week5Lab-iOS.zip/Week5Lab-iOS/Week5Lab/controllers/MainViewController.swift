import UIKit

class MainViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    @IBOutlet weak var collectionView: UICollectionView!
    var sets = [FlashcardSet]()

    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        sets = FlashcardHelper.loadFlashcardSets()
    }

    @IBAction func addFlashcardSet(_ sender: Any) {
        FlashcardHelper.addNewSet(titled: "Untitled Set")
        sets = FlashcardHelper.loadFlashcardSets()
        collectionView.reloadData()
        if sets.count > 0 {
            collectionView.scrollToItem(at: IndexPath(item: sets.count - 1, section: 0), at: .bottom, animated: true)
        }
    }

    func collectionView(_ c: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return sets.count
    }

    func collectionView(_ c: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = c.dequeueReusableCell(withReuseIdentifier: "FlashcardSetCell", for: indexPath) as! FlashcardSetCollectionCell
        cell.myLabel.text = sets[indexPath.item].title
        return cell
    }

    func collectionView(_ c: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        performSegue(withIdentifier: "GoToDetail", sender: nil)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "GoToDetail",
           let target = segue.destination as? FlashcardSetDetailViewController,
           let idx = collectionView.indexPathsForSelectedItems?.first?.item {
            target.flashcardSet = sets[idx]
        }
    }
}

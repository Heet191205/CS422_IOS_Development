//
//  FlashcardSet+CoreDataClass.swift
//  Week5Lab
//
//  Created by JeetPatel on 7/5/25.
//
//

import Foundation
import CoreData

@objc(FlashcardSet)
public class FlashcardSet: NSManagedObject {

}

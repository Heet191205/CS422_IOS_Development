//
//  Flashcard+CoreDataProperties.swift
//  Week5Lab
//
//  Created by JeetPatel on 7/6/25.
//
//

import Foundation
import CoreData


extension Flashcard {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Flashcard> {
        return NSFetchRequest<Flashcard>(entityName: "Flashcard")
    }

    @NSManaged public var definition: String?
    @NSManaged public var term: String?
    @NSManaged public var set: FlashcardSet?

}

extension Flashcard : Identifiable {

}
